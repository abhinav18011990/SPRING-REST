package com.example.two.SpringRestLogin.service;

import com.example.two.SpringRestLogin.entity.User;

public interface UserService {
	
	public  String check(User u);

}
