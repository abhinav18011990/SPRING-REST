package com.example.two.SpringRestLogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
