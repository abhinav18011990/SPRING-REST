package com.example.two.SpringRestHelloWorld;

import org.springframework.stereotype.Service;

@Service
public class ServiceHello {
	
	public String hello() {
		return "Hello World";
		
	}

}
